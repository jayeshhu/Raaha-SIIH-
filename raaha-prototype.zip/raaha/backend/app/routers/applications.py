from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Application, Citizen, AuditLog
from ..schemas import ApplicationCreate, ApplicationOut, AuditOut

router = APIRouter(prefix="/applications", tags=["applications"])

@router.post("", response_model=ApplicationOut)
def create_application(payload: ApplicationCreate, db: Session = Depends(get_db)):
    citizen = db.get(Citizen, payload.citizen_id)
    if not citizen:
        citizen = Citizen(id=payload.citizen_id, name=payload.name)
        db.add(citizen)
    app = Application(id="APP-" + uuid4().hex[:6].upper(), citizen_id=payload.citizen_id, service=payload.service)
    db.add(app); db.add(AuditLog(application_id=app.id, message="Application submitted")); db.commit(); db.refresh(app)
    return app

@router.get("", response_model=list[ApplicationOut])
def list_applications(db: Session = Depends(get_db)):
    return db.query(Application).order_by(Application.created_at.desc()).all()

@router.get("/{application_id}", response_model=ApplicationOut)
def get_application(application_id: str, db: Session = Depends(get_db)):
    app = db.get(Application, application_id)
    if not app: raise HTTPException(404, "Application not found")
    return app

@router.get("/{application_id}/audit", response_model=list[AuditOut])
def audit(application_id: str, db: Session = Depends(get_db)):
    return db.query(AuditLog).filter_by(application_id=application_id).order_by(AuditLog.created_at).all()
