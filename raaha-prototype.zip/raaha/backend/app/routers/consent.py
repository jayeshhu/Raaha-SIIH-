from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Consent
from ..schemas import ConsentCreate
router = APIRouter(prefix="/consents", tags=["consent"])
@router.post("")
def create_consent(payload: ConsentCreate, db: Session = Depends(get_db)):
    consent = Consent(**payload.model_dump()); db.add(consent); db.commit(); db.refresh(consent)
    return {"id": consent.id, "citizen_id": consent.citizen_id, "service": consent.service, "granted": consent.granted}
@router.get("/{citizen_id}")
def get_consent(citizen_id: str, db: Session = Depends(get_db)):
    return db.query(Consent).filter_by(citizen_id=citizen_id).order_by(Consent.created_at.desc()).first()
