from datetime import datetime
from typing import Any
from pydantic import BaseModel, ConfigDict

class ApplicationCreate(BaseModel):
    citizen_id: str
    name: str
    service: str = "Scholarship Verification"

class ApplicationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    citizen_id: str
    service: str
    status: str
    created_at: datetime

class ConsentCreate(BaseModel):
    citizen_id: str
    service: str = "Scholarship Verification"
    granted: bool = True

class VerificationResult(BaseModel):
    department: str
    verified: bool
    message: str
    data: dict[str, Any] = {}

class AuditOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: str
    message: str
    created_at: datetime
