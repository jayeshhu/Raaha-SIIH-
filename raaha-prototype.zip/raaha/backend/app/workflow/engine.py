from sqlalchemy.orm import Session
from ..models import Application, AuditLog, Consent, WorkflowState as WorkflowStateModel
from ..adapters.education import EducationAdapter
from ..adapters.income import IncomeAdapter
from ..adapters.welfare import WelfareAdapter
from .states import WorkflowState

class WorkflowEngine:
    def __init__(self, db: Session):
        self.db = db
        self.adapters = [EducationAdapter(), IncomeAdapter(), WelfareAdapter()]

    def log(self, application_id, message):
        self.db.add(AuditLog(application_id=application_id, message=message))

    def set_state(self, application, state):
        application.status = state
        self.db.add(WorkflowStateModel(application_id=application.id, state=state))

    def run(self, application: Application):
        consent = self.db.query(Consent).filter_by(citizen_id=application.citizen_id, service=application.service, granted=True).first()
        if not consent:
            raise ValueError("Citizen consent is required before verification")

        self.log(application.id, "Application workflow started")
        states = [WorkflowState.EDUCATION_VERIFICATION, WorkflowState.INCOME_VERIFICATION, WorkflowState.WELFARE_VERIFICATION]
        for state, adapter in zip(states, self.adapters):
            self.set_state(application, state)
            self.log(application.id, f"{adapter.__class__.__name__.replace('Adapter','')} verification started")
            result = adapter.verify(application.citizen_id)
            self.log(application.id, result.message)
            if not result.verified:
                self.set_state(application, WorkflowState.FAILED)
                self.log(application.id, "Application failed verification")
                self.db.commit()
                return application
        self.set_state(application, WorkflowState.COMPLETED)
        self.log(application.id, "Scholarship verification completed")
        self.db.commit()
        return application
