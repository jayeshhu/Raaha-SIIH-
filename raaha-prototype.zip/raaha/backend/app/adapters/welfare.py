from pathlib import Path
import xml.etree.ElementTree as ET
from .base import DepartmentAdapter
from ..schemas import VerificationResult

class WelfareAdapter(DepartmentAdapter):
    def verify(self, citizen_id: str) -> VerificationResult:
        root = ET.fromstring((Path(__file__).parent.parent / "mock_departments/welfare.xml").read_text())
        data = {child.tag: (child.text or "") for child in root}
        verified = data.get("citizen_id") == citizen_id and data.get("eligible") == "true"
        return VerificationResult(department="Welfare Department", verified=verified,
            message="Welfare eligibility verified" if verified else "Welfare eligibility failed", data=data)
