import json
from pathlib import Path
from .base import DepartmentAdapter
from ..schemas import VerificationResult

class EducationAdapter(DepartmentAdapter):
    def verify(self, citizen_id: str) -> VerificationResult:
        data = json.loads((Path(__file__).parent.parent / "mock_departments/education.json").read_text())
        verified = data["enrolled"] and data["student_id"] == citizen_id
        return VerificationResult(department="Education Department", verified=verified,
            message="Enrollment verified" if verified else "Enrollment not verified", data=data)
