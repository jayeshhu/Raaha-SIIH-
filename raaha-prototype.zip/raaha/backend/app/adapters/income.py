import json
from pathlib import Path
from .base import DepartmentAdapter
from ..schemas import VerificationResult

class IncomeAdapter(DepartmentAdapter):
    def verify(self, citizen_id: str) -> VerificationResult:
        data = json.loads((Path(__file__).parent.parent / "mock_departments/income.json").read_text())
        verified = data["citizen_id"] == citizen_id and data["income_eligible"]
        return VerificationResult(department="Income Department", verified=verified,
            message="Income eligible" if verified else "Income eligibility failed", data=data)
