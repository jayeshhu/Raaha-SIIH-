import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
os.environ["DATABASE_URL"] = "sqlite:///./test.db"
from fastapi.testclient import TestClient
from app.main import app
from app.database import Base, engine

Base.metadata.drop_all(bind=engine); Base.metadata.create_all(bind=engine)
client = TestClient(app)

def test_health():
    assert client.get("/health").json() == {"status": "ok"}

def test_complete_workflow():
    r = client.post("/applications", json={"citizen_id":"CIT001","name":"Demo Student"})
    assert r.status_code == 200
    app_id = r.json()["id"]
    assert client.post("/consents", json={"citizen_id":"CIT001","granted":True}).status_code == 200
    result = client.post(f"/workflows/{app_id}/start")
    assert result.status_code == 200
    assert result.json()["status"] == "COMPLETED"
    audit = client.get(f"/applications/{app_id}/audit").json()
    assert len(audit) >= 5

def test_workflow_requires_consent():
    r = client.post("/applications", json={"citizen_id":"CIT002","name":"No Consent"})
    result = client.post(f"/workflows/{r.json()['id']}/start")
    assert result.status_code == 400
